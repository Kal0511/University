/*
* File Name: Observer.java
* Assignment: Lab 5 
* Lab Section: B01
* Completed by: Kaumil Patel
* Submission Date: Nov 4, 2021
*/

import java.util.ArrayList;

public interface Observer {
	void update(ArrayList<Double> arr);
}
