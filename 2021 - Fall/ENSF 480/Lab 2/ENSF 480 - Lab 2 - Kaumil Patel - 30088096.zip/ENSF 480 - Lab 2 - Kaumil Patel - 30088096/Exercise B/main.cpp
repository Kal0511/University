/*
* File Name: main.cpp
* Assignment: Lab 2 Exercise B
* Lab Section: B01
* Completed by: Kaumil Patel
* Submission Date: Sept 30, 2021
*/

#include "graphicsWorld.h"

int main() {
    GraphicsWorld::run();
    return 0;
}