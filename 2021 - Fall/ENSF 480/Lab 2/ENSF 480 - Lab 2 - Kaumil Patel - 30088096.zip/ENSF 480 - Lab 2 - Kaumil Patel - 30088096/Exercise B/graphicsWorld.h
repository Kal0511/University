/*
* File Name: graphicsWorld.h
* Assignment: Lab 2 Exercise B
* Lab Section: B01
* Completed by: Kaumil Patel
* Submission Date: Sept 30, 2021
*/

#ifndef EXERCISE_B_GRAPHICWORLD_H
#define EXERCISE_B_GRAPHICWORLD_H

class GraphicsWorld {
public:
    static void run();
};

#endif