//
// Created by spdmo on 10/20/2021.
//

#ifndef EXERCISE_C_MOVEABLE_H
#define EXERCISE_C_MOVEABLE_H

class Moveable{
public:
    virtual void forward() = 0;
    virtual void backward() = 0;
};

#endif //EXERCISE_C_MOVEABLE_H
