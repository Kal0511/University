/*
* File Name: Name.h
* Assignment: Lab 1 Exercise C
* Completed by: Kaumil Patel
* Submission Date: Sept 23, 2020
*/

#ifndef EXERCISE_C_NAME_H
#define EXERCISE_C_NAME_H


class Name {
private:
    std::string first;
    std::string middle;
    std::string last;
public:
};


#endif //EXERCISE_C_NAME_H
