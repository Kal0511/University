/*
* File Name: company.cpp
* Assignment: Lab 1 Exercise C
* Completed by: Kaumil Patel
* Submission Date: Sept 23, 2020
*/

#include <string>
#include <vector>

#include "Employee.h"
#include "Customer.h"

using namespace std;

class Company {
private:
    string companyName;
    Address companyAdderss;
    Date dateEstablished;
    vector<Employee> employees;
    vector<Customer> customers;
public:
};

int main(){
    return 0;
}