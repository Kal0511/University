/*
* File Name: Date.h
* Assignment: Lab 1 Exercise C
* Completed by: Kaumil Patel
* Submission Date: Sept 23, 2020
*/

#ifndef EXERCISE_C_DATE_H
#define EXERCISE_C_DATE_H


class Date {
private:
    int day;
    int month;
    int year;
public:
};


#endif //EXERCISE_C_DATE_H
