/*
* File Name: human_program.cpp
* Assignment: Lab 1 Exercise D
* Completed by: Kaumil Patel
* Submission Date: Sept 23, 2020
*/

#include "human.h"

int main(int argc, char **argv) {
    double x = 2000, y = 3000;
    Human h("Ken Lai", x, y);
    h.display();
    return 0;
}
